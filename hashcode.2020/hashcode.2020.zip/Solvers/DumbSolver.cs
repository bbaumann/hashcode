﻿using System;
using System.Collections.Generic;
using System.Text;
using hashcode._2020.Models;

namespace hashcode._2020.Solvers
{
    public class DumbSolver : BaseSolver
    {
        public DumbSolver(bool isDeterministic) : base(isDeterministic)
        {
        }

        protected override void DoSolve(Solution res)
        {
            
        }
    }
}
